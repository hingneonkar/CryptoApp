import React, { useState } from 'react'
import CoinItem from './CoinItem'
import Coin from '../routes/Coin'
import { Link } from 'react-router-dom'

import './Coins.css'

const Coins = (props) => {

    const [data, setdata]=useState('')

    





    return (
            <>
            <div className='coins'>
            <input type="text" placeholder='search here...' className='coins1' onChange={(e)=>{setdata(e.target.value)}}   />
            </div>

        <div className='container' style={{color:"blueviolet"}} >
            <div>
                <div className='heading'>
                    <p>#</p>
                    <p className='coin-name'style={{marginLeft:"10px"}} >Coin</p>
                    <p>Price</p>
                    <p>24h</p>
                    <p className='hide-mobile'style={{marginRight:"50px"}} >Volume</p>
                    <p className='hide-mobile'>Mkt Cap</p>
                </div>

                {props.coins.filter((coins)=>coins.name.toLowerCase().includes(data)). map(coins => {
                    return (
                        <Link to={`/coin/${coins.id}`} element={<Coin />} key={coins.id}>
                            <CoinItem coins={coins} />
                        </Link>

                    )
                })}

            </div>
        </div>
        </>
    )
}

export default Coins
